@echo off
echo AutoPilot Android debug build
echo Open this folder in Android Studio first and let Gradle sync.
gradlew.bat assembleDebug
pause
